Python package for the RC4 algorithm
====================================
